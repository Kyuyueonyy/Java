package ch06.sec06.exam01;

public class Car {
    //필드 선언
    String model; //null
    boolean start; //false
    int speed; //0

}
